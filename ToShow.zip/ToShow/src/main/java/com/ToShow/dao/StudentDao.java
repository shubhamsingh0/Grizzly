package com.ToShow.dao;

import com.ToShow.model.Student;

public interface StudentDao {

	public Student save(Student student);
	public Student fetchById(Long id);
	public boolean deleteById(Long id);
	public Student updateStudentDetails(Student student);
	
	
}
