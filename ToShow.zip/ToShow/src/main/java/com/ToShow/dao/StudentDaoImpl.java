package com.ToShow.dao;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ToShow.model.Student;
@Repository
public class StudentDaoImpl implements StudentDao{
	
	@Autowired
	SessionFactory sessionFactory;
	

	public Student save(Student student) {
		// TODO Auto-generated method stub
	Session session=sessionFactory.getCurrentSession();
	try{session.save(student);
	}catch(Exception e) {
		e.printStackTrace();
	}
	if(fetchById(student.getId())!=null)
	{
		return student;
	}
	return null;
	}

	public Student fetchById(Long id) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from Student s where s.studentId=?");
		query.setParameter(0,id);
		Student student=(Student)query.getSingleResult();
		if(student!=null)
			return student;
		return null;
	}

	public boolean deleteById(Long id) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("delete from Student s where s.studentId=?");
		query.setParameter(0, id);
		if(fetchById(id)!=null)
		{
			return false;
		}
		return true;
	}

	public Student updateStudentDetails(Student student) {
		// TODO Auto-generated method stub
		
		
		
		
		return null;
	}

}
